# gawf

datagolf.py
- Contains methods to query datagolf API

owgr.py
- Contains script to pull OWGR rankings

/data/
- Contains CSVs for data pulls

database.py
- Crawls /data/ and creates total DFs from files
